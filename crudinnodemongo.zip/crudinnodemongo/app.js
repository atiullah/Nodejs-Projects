var express = require('express');
const mongoose = require('mongoose');
var db1 = require('./Modal/dbContext')

var app = express()
var bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.set('views', './Views')
app.set('view engine', 'ejs')

app.get('/', (req, res) => {
  //   ------------SELECT RECORD ----------------
  // if(req.params.search==''){
      console.log(req.params)
  db.collection('Employees').find().toArray(function (findErr, result) {
    if (findErr) throw findErr;
    res.render('index.ejs', {
      result: result
    })
  });
// }
})
 
app.get('/create', (req, res) => {
  res.render('create.ejs')
})

app.post('/createRecord', function (req, res) {
  console.log(req.body);
  //   ------------INSERT RECORD ----------------
  db.collection('Employees', function (err, collection) {
    collection.insertOne(
      {
        Firstname: req.body.firstname,
        Lastname: req.body.lastname,
        Email: req.body.email,
        County: req.body.country,
        Phone: req.body.phone,
        Zipcode: req.body.zipcode,
        Address: req.body.address
      })
    res.redirect('/')
  })
})

app.get('/Edit/:_id', (req, res) => {
  // console.log(req.params._id)
  db.collection('Employees', function (err, db) {
    if (err) throw err;
    db.findOne({ _id: mongoose.Types.ObjectId(req.params._id) }, function (err, result) {
      // console.log(result)
      res.render('edit.ejs', {
        result
      })
    })
  })
})

app.post('/UpdateRecord', function (req, res) {
  // console.log(req.body);
  //   ------------INSERT RECORD ----------------
  db.collection('Employees', function (err, collection) {
    collection.updateMany(
      {
        _id: mongoose.Types.ObjectId(req.body._id)
      },
      {
        $set: {
          Firstname: req.body.firstname,
          Lastname: req.body.lastname,
          Email: req.body.email,
          County: req.body.country,
          Phone: req.body.phone,
          Zipcode: req.body.zipcode,
          Address: req.body.address
        }
      }, function (err, result) {
        if (err) throw err
        res.redirect('/')
      })
  })
})

app.get('/Detail/:_id', (req, res) => {
  // console.log(req.params._id)
  db.collection('Employees', function (err, db) {
    if (err) throw err;
    db.findOne({ _id: mongoose.Types.ObjectId(req.params._id) }, function (err, result) {
      //  console.log(result)
      res.render('Detail.ejs', {
        result
      })
    })
  })
})

app.get('/Delete/:_id', (req, res) => {
  // console.log(req.params._id)
  db.collection('Employees', function (err, db) {
    if (err) throw err;
    db.remove({ _id: mongoose.Types.ObjectId(req.params._id) }, function (err, result) {
      res.redirect('/')
    })
  })
})


app.listen(7466, () => {
  console.log("Watch Magic on Port 7466")
})