var MongoClient = require('mongodb').MongoClient;
MongoClient.connect('mongodb://localhost',{ useNewUrlParser: true } , function (err, client) {
  if (err) throw err;
  var db = client.db('mydb');
  global.db = db
})
